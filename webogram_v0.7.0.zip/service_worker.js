/* global importScripts */
importScripts('js/lib/push_worker.js')

// Version 53
